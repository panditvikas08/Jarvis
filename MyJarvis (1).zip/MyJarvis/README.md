# MyJarvis - APK Bina Android Studio Ke Banao

Ye tareeka GitHub ki free service use karega jo tere liye APK bana kar dega. Tujhe kuch install nahi karna.

## STEP 1: Apni API key daal do (zaroori)
1. Is folder me `app/src/main/java/com/example/myjarvis/MainActivity.kt` file kholo (Notepad se bhi khul jayegi)
2. Upar dhoondo ye line:
   ```
   const val API_KEY = "PASTE_YOUR_API_KEY_HERE"
   ```
3. https://console.anthropic.com pe jaake account banao -> "API Keys" -> naya key banao -> copy karo
4. `PASTE_YOUR_API_KEY_HERE` ki jagah apni key paste karo (quotes ke andar hi), file save karo

## STEP 2: GitHub pe account banao
1. https://github.com pe jao -> "Sign up" -> free account banao

## STEP 3: Naya repository banao
1. Login ke baad upar-right corner me "+" icon -> "New repository"
2. Naam do: `MyJarvis`
3. **Private** select karo (important - taki tumhari API key kisi ko na dikhe)
4. "Create repository" button dabao

## STEP 4: Apni files upload karo
1. Naye repo page pe "uploading an existing file" link pe click karo
2. Is poore `MyJarvis` folder ke andar ki saari files aur folders drag-drop karke upload karo
   (folder ke andar jao, sab select karo - `.github`, `app`, `settings.gradle`, `build.gradle`, `gradle.properties` - sabkuch)
3. Neeche "Commit changes" button dabao

## STEP 5: APK banne do (automatic)
1. Upload hote hi upar "Actions" tab pe jao
2. Ek build chal raha hoga (yellow dot = chal raha hai, green tick = ban gaya)
3. **5-8 minute wait karo**
4. Green tick aane ke baad us build pe click karo
5. Neeche "Artifacts" section me "MyJarvis-APK" dikhega - usme click karke download karo (zip file aayegi)

## STEP 6: Phone me install karo
1. Downloaded zip ko extract karo, andar `app-debug.apk` file milegi
2. Ye file apne Android phone me bhejo (WhatsApp/email/USB - kaise bhi)
3. Phone me us APK file pe tap karo
4. Agar "Install blocked" ka message aaye: Settings me uska option "Allow from this source" ON karo, phir wapas try karo
5. Install ho jayegi

## STEP 7: Permissions do
App kholte hi Microphone, Call, SMS, Contacts ki permission maangega - sab Allow karo.

## Use kaise karna hai
1. App khol ke "Assistant Shuru Karo" dabao
2. Bolo: "Jarvis"
3. Wo bolega "Haan bhai, bolo"
4. Bolo:
   - "call [naam]" -> call lagayega
   - "message [naam] [text]" -> SMS bhejega
   - "open [app naam]" -> app khol dega
   - koi bhi general sawaal -> jawab dega bolke

## Agar Build fail ho jaye (Actions tab me red cross)
Us failed build pe click karke jo error likha hai uska screenshot mujhe bhej dena, main turant fix kar dunga - tereko sirf file dobara upload karni hogi.

## Yaad rakhna
- Repo Private hi rakhna (API key ki suraksha ke liye)
- Jab bhi koi file change karke dobara upload karoge, naya APK apne aap 5-8 min me ban jayega Actions tab me
